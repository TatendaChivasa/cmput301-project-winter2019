package ca.ualberta.cs.lonelytwitter;

/**
 * @author: Created by vinaykum
 * @since: on 1/9/19.
 */

public class importantTweet extends Tweet {

    public void importantTweet(){

    }

    /**
     *
     * @param: firstMessage
     * @param: secondMessage
     * @param: with second message
     */
    public void setMessage(String firstMessage, String secondMessage){

        message = firstMessage;
        message2 = secondMessage;

    }

    public String getSomething(){

        return null;
    }

}
