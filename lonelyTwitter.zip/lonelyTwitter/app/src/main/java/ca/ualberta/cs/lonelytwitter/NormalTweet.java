package ca.ualberta.cs.lonelytwitter;

/**
 * The type Normal tweet.
 */
public class NormalTweet extends Tweet {
    /**
     * Instantiates a new Normal tweet.
     */
    NormalTweet() {
        super();
    }

    /**
     * Instantiates a new Normal tweet.
     *
     * @param message the message
     */
    NormalTweet(String message) {
       // super(message);
    }


    public Boolean isImportant() {
        return false;
    }
}
