package ca.ualberta.cs.lonelytwitter;

import java.util.Date;

/**
 * @author: Created by vinaykum
 * @since: on 1/9/19.
 * @version: Version edited by Tatenda Chivasa
 */

public abstract class Tweet {

    String message;

    String message2;

    Date date;

    /**
     * @param: takes no parameters
     */
    public void Tweet(){

        message = "" ;

    }

    public void setMessage(String tweetmessage){

        message = tweetmessage;
    }

    public String getMessage(){
        return message;
    }

    public void setMessage(String tweetmessage, String message2){
        message = tweetmessage;
        this.message2 = message2;

        System.out.println("second setMessage has been called");
    }

  //  public abstract String getSomething();
}
